# 简介

介绍 JavaScript 语言及其开发环境。
