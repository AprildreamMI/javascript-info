importance: 5

---

# 重写为 class

`Clock` 类（请见沙箱）是以函数式编写的。请以 "class" 语法重写它。

P.S. 时钟在控制台（console）中滴答，打开控制台即可查看。
