importance: 5

---

# 反向输出单链表

反向输出前一个任务 <info:task/output-single-linked-list> 中的单链表。

使用两种解法：循环和递归。
