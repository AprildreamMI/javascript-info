答案：`undefined`。

`bind` 的结果是另一个对象。它并没有 `test` 属性。

