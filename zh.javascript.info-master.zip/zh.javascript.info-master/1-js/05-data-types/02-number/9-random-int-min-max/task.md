importance: 2

---

# 从 min 到 max 的随机整数

创建一个函数 `randomInteger(min，max)`，该函数会生成一个范围在 `min` 到 `max` 中的随机整数，包括 `min` 和 `max`。

在 `min..max` 范围中的所有数字的出现概率必须相同。


运行示例：

```js
alert( randomInteger(1, 5) ); // 1
alert( randomInteger(1, 5) ); // 3
alert( randomInteger(1, 5) ); // 5
```

你可以使用 [上一个任务](info:task/random-min-max) 的解决方案作为基础。
