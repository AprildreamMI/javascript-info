importance: 4

---

# 数组去重

`arr` 是一个数组。

创建一个函数 `unique(arr)`，返回去除重复元素后的数组 `arr`。

例如：

```js
function unique(arr) {
  /* your code */
}

let strings = ["Hare", "Krishna", "Hare", "Krishna",
  "Krishna", "Krishna", "Hare", "Hare", ":-O"
];

alert( unique(strings) ); // Hare, Krishna, :-O
```
