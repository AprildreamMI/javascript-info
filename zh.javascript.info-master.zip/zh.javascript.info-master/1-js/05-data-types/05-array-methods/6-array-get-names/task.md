importance: 5

---

# 映射到 names

你有一个 `user` 对象数组，每个对象都有 `user.name`。编写将其转换为 names 数组的代码。

例如：

```js no-beautify
let john = { name: "John", age: 25 };
let pete = { name: "Pete", age: 30 };
let mary = { name: "Mary", age: 28 };

let users = [ john, pete, mary ];

let names = /* ... your code */

alert( names ); // John, Pete, Mary
```

