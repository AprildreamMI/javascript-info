function extractCurrencyValue(str) {
  return +str.slice(1);
}