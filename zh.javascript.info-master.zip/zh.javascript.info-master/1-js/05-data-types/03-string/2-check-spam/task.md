importance: 5

---

# 检查 spam

写一个函数 `checkSpam(str)`，如果 `str` 包含 `viagra` 或 `XXX` 就返回 `true`，否则返回 `false`。

函数必须不区分大小写：

```js
checkSpam('buy ViAgRA now') == true
checkSpam('free xxxxx') == true
checkSpam("innocent rabbit") == false
```

