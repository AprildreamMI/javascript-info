importance: 5

---

# 首字母大写

写一个函数 `ucFirst(str)`，并返回首字母大写的字符串 `str`，例如：

```js
ucFirst("john") == "John";
```

