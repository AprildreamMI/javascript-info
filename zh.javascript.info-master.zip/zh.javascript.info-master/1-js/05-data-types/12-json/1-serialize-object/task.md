importance: 5

---

# 将对象转换为 JSON，然后再转换回来

将 `user` 转换为 JSON，然后将其转换回到另一个变量。

```js
let user = {
  name: "John Smith",
  age: 35
};
```
