importance: 5

---

# 创建日期

创建一个 `Date` 对象，日期是：Feb 20, 2012, 3:12am。时区是当地时区。

使用 `alert` 显示结果。
