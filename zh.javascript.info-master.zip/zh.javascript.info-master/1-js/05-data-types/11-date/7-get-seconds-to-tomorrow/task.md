importance: 5

---

# 距离明天还有多少秒？

写一个函数 `getSecondsToTomorrow()`，返回距离明天的秒数。

例如，现在是 `23:00`，那么：

```js
getSecondsToTomorrow() == 3600
```

P.S. 该函数应该在任意一天都能正确运行。那意味着，它不应具有“今天”的硬编码值。
