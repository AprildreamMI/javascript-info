importance: 5

---

# 显示星期数

编写一个函数 `getWeekDay(date)` 以短格式来显示一个日期的星期数：'MO'，'TU'，'WE'，'TH'，'FR'，'SA'，'SU'。

例如：

```js no-beautify
let date = new Date(2012, 0, 3);  // 3 Jan 2012
alert( getWeekDay(date) );        // 应该输出 "TU"
```
