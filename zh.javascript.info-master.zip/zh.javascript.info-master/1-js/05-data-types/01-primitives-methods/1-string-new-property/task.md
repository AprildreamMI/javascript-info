importance: 5

---

# 我能为字符串添加一个属性吗？


思考下面的代码：

```js
let str = "Hello";

str.test = 5;

alert(str.test);
```

你怎么想的呢，它会工作吗？会得到什么样的结果？
