
1. `true`，来自于 `rabbit`。
2. `null`，来自于 `animal`。
3. `undefined`，不再有这样的属性存在。
