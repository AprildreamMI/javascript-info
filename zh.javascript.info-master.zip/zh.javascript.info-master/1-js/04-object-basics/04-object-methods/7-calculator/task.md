importance: 5

---

# 创建一个计算器

创建一个有三个方法的 `calculator` 对象：

- `read()` 提示输入两个值，并将其保存为对象属性。
- `sum()` 返回保存的值的和。
- `mul()` 将保存的值相乘并返回计算结果。

```js
let calculator = {
  // ……你的代码……
};

calculator.read();
alert( calculator.sum() );
alert( calculator.mul() );
```

[demo]
