只需要遍历这个对象，如果对象存在任何属性则 `return false`。
