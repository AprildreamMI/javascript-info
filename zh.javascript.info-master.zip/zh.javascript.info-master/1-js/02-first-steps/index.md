# JavaScript 基础知识

让我们来一起学习 JavaScript 脚本构建的基础知识。
