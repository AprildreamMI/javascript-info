importance: 5

---

# 后置运算符和前置运算符

以下代码中变量 `a`、`b`、`c`、`d` 的最终值分别是多少？

```js
let a = 1, b = 1;

let c = ++a; // ?
let d = b++; // ?
```
