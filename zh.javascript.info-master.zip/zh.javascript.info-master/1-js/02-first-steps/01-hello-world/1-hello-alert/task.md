importance: 5

---

# 显示一个提示语

创建一个页面，然后显示一个消息 “I'm JavaScript!”。

在沙箱中或者在你的硬盘上做这件事都无所谓，只要确保它能运行起来。

[demo src="solution"]
