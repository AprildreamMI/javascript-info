HTML 代码:

[html src="index.html"]

同一个文件夹中的 `alert.js` 文件：

[js src="alert.js"]

