importance: 5

---

# 使用 '?' 重写 'if' 语句

使用条件运算符 `'?'` 重写下面的 `if` 语句：

```js
let result;

if (a + b < 4) {
  result = 'Below';
} else {
  result = 'Over';
}
```
