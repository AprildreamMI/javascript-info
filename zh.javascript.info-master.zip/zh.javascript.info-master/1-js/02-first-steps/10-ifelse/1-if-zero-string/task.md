importance: 5

---

# if（值为 0 的字符串）

`alert` 弹窗会出来吗？

```js
if ("0") {
  alert( 'Hello' );
}
```
