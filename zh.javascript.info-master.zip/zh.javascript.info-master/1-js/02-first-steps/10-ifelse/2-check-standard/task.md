importance: 2

---

# JavaScript 的名字

使用 `if..else` 结构，实现提问 "What is the "official" name of JavaScript?" 的代码

如果访问者输入了 "ECMAScript"，输出就提示 "Right!"，否则 — 输出："Didn't know? ECMAScript!"

![](ifelse_task2.svg)

[demo src="ifelse_task2"]

