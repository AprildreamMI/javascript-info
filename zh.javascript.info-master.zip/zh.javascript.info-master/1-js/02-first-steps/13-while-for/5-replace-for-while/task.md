importance: 5

---

# 用 "while" 替换 "for"

重写代码，在保证不改变其行为的情况下，将 `for` 循环更改为 `while`（输出应保持不变）。

```js run
for (let i = 0; i < 3; i++) {
  alert( `number ${i}!` );
}
```

