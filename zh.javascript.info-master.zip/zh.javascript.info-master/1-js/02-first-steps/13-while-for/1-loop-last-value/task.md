importance: 3

---

# 最后一次循环的值

此代码最后一次 alert 值是多少？为什么？

```js
let i = 3;

while (i) {
  alert( i-- );
}
```
