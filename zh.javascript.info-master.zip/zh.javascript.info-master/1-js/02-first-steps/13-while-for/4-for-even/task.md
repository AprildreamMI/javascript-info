importance: 5

---

# 使用 for 循环输出偶数

使用 `for` 循环输出从 `2` 到 `10` 的偶数。

[demo]
