

```js run demo
for (let i = 2; i <= 10; i++) {
  if (i % 2 == 0) {
    alert( i );
  }
}
```

我们使用 "modulo" 运算符 `%` 来获取余数，并检查奇偶性。
