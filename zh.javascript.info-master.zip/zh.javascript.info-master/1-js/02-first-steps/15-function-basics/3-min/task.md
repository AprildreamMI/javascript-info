importance: 1

---

# 函数 min(a, b)

写一个返回数字 `a` 和 `b` 中较小的那个数字的函数 `min(a,b)`。

例如：

```js
min(2, 5) == 2
min(3, -1) == -1
min(1, 1) == 1
```

