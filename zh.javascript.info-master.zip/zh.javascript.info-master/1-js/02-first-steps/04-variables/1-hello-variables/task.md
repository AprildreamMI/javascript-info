importance: 2

---

# 使用变量

1. 声明两个变量：`admin` 和 `name`。
2. 将值 `"John"` 赋给 `name`。
3. 从 `name` 变量中拷贝其值给 `admin`。
4. 使用 `alert` 显示 `admin` 的值（必须输出 "John"）。
