下面的代码，每一行都对应着任务列表中的对应项。

```js run
let admin, name; // 一次声明两个变量。

name = "John";

admin = name;

alert( admin ); // "John"
```

