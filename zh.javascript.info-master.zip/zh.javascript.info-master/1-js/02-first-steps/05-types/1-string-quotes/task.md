importance: 5

---

# 字符串的引号

下面的脚本会输出什么？

```js
let name = "Ilya";

alert( `hello ${1}` ); // ?

alert( `hello ${"name"}` ); // ?

alert( `hello ${name}` ); // ?
```
