结果是 `2`，这是第一个真值。

```js run
alert( null || 2 || undefined );
```

