importance: 5

---

# 或运算的结果是什么？

如下代码将会输出什么？

```js
alert( null || 2 || undefined );
```

