importance: 3

---

# 或运算和 alerts 的结果是什么？

下面的代码将会输出什么？

```js
alert( alert(1) || 2 || alert(3) );
```

