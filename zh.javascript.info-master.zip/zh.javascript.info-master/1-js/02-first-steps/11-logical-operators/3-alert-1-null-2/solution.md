答案：`null`，因为它是列表中第一个假值。

```js run
alert( 1 && null && 2 );
```

