importance: 5

---

# 与操作的结果是什么？

下面这段代码将会显示什么？

```js
alert( 1 && null && 2 );
```

