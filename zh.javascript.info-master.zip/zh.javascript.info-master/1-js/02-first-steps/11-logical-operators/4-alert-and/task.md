importance: 3

---

# 与运算连接的 alerts 的结果是什么？

这段代码将会显示什么？

```js
alert( alert(1) && alert(2) );
```

